import pygame.event

SELECT_DAMAGE_TOWER = pygame.event.custom_type()

SELECT_MONEY_TOWER = pygame.event.custom_type()

SELECT_TOWER = pygame.event.custom_type()

MONEY_UPDATE = pygame.event.custom_type()

PRICE_UPDATE = pygame.event.custom_type()

GAME_OVER = pygame.event.custom_type()

GIVE_MONEY = pygame.event.custom_type()

UPGRADE_TOWER_RANGE = pygame.event.custom_type()

UPGRADE_TOWER_SPEED = pygame.event.custom_type()

UPGRADE_TOWER_ATK = pygame.event.custom_type()

UPGRADE_FIELD_AMOUNT = pygame.event.custom_type()

UPGRADE_FIELD_SPEED = pygame.event.custom_type()

ENABLE_AUTO_HARVEST = pygame.event.custom_type()

REFRESH_MENU = pygame.event.custom_type()

UNSELECT_TOWER = pygame.event.custom_type()

UPGRADE_VILLAGE = pygame.event.custom_type()